module Liftoff
  VERSION = '1.8.4'
end
