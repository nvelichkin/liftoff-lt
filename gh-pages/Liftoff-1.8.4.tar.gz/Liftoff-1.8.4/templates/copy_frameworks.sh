/usr/local/bin/carthage copy-frameworks
